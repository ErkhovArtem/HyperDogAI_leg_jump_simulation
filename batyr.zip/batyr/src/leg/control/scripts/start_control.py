#!/usr/bin/env python3
import rospy
from sensor_msgs.msg import JointState
from std_msgs.msg import Float64
import numpy as np
import time
from controller_manager_msgs.srv import SwitchController


class Controller:
    def __init__(self) -> None:
        self.current_angles = np.array([0, 0, 0])
        self.effort_publishers = [
            rospy.Publisher("/leg/joint_position_controller_4/command", Float64, queue_size=10),
            rospy.Publisher("/leg/joint_effort_controller_6/command", Float64, queue_size=10),
            rospy.Publisher("/leg/joint_effort_controller_8/command", Float64, queue_size=10),
        ]

        self.effort_publishers_position = [
            rospy.Publisher("/leg/joint_position_controller_4/command", Float64, queue_size=10),
            rospy.Publisher("/leg/joint_position_controller_6/command", Float64, queue_size=10),
            rospy.Publisher("/leg/joint_position_controller_8/command", Float64, queue_size=10),
        ]

    def set_current_angles(self, angles):
        self.current_angles = angles

    def apply_effort(self, efforts):
        for pub, effort in zip(self.effort_publishers, efforts):
            pub.publish(Float64(effort))

    def apply_effort_position(self, efforts):
        for pub, effort in zip(self.effort_publishers_position, efforts):
            pub.publish(Float64(effort))


class RosManager:
    def __init__(self) -> None:
        rospy.init_node("listener", anonymous=True)
        self.controller = Controller()
        rospy.Subscriber("/leg/joint_states", JointState, self.listen_joint_state)

    def spin(self):
        rate = rospy.Rate(10)

        # constant_efforts = [0, 0, 0]  # Задаем постоянные моменты для суставов
        
        start_time = time.perf_counter()
        
        # constant_efforts = [10.1, -25]  # Задаем постоянные моменты для суставов

        while not rospy.is_shutdown():
            
            # position_efforts = [1, 1, 1]    
            # self.controller.apply_effort_position(position_efforts)
            # rate.sleep()

            
            # if (time.perf_counter() - start_time) < 10:
            rospy.wait_for_service('/leg/controller_manager/switch_controller')
            switch_controller = rospy.ServiceProxy('/leg/controller_manager/switch_controller', SwitchController)
            ret = switch_controller(start_controllers=['joint_position_controller_6', 'joint_position_controller_8'],
                                    stop_controllers=['joint_effort_controller_6', 'joint_effort_controller_8'], strictness=1)
            position_efforts = [0, 0, -0.6]    
            self.controller.apply_effort_position(position_efforts)
            rate.sleep()

                # constant_efforts = [0, 0, 0]    
                # self.controller.apply_effort(constant_efforts)
                # rate.sleep()

            # else:
            #     if (time.perf_counter() - start_time) > 10:
            #         constant_efforts = [0, 8, -20]    
            #     else:
            #         constant_efforts = [0, 12, -25] 
            #     self.controller.apply_effort(constant_efforts)    
            rate.sleep()



    def listen_joint_state(self, msg: JointState):
        angles = np.array(msg.position[:-1])
        self.controller.set_current_angles(angles)


if __name__ == "__main__":
    # rospy.wait_for_service('/leg/controller_manager/switch_controller')
    # switch_controller = rospy.ServiceProxy('/leg/controller_manager/switch_controller', SwitchController)
    # ret = switch_controller(start_controllers=['joint_effort_controller_6', 'joint_effort_controller_8'],
    #                         stop_controllers=['joint_position_controller_6', 'joint_position_controller_8'], strictness=1)
    ros_manager = RosManager()
    ros_manager.spin()

